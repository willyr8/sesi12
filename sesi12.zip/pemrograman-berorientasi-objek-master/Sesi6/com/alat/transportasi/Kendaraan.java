package com.alat.transportasi;

import com.alat.transportasi.beroda.*;

public class Kendaraan {

    public static void main(String[] args) {
        System.out.println("Belajar package dan interface");
    }
}
