
package com.alat.transportasi.beroda;

public class KendaraanBeroda {
    
}
