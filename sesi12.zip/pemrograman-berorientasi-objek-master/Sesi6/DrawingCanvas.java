import java.awt.Color;
import java.awt.*;

public class DrawingCanvas {
    
}
