# Pengertian dari tugas sesi 4.

- Clothes.java
  ini memakai sebuah override method. class Clothes dan class Sweater . class Sweater memperluas class Clothes. Kedua class memiliki metode umum void style(). class Sweater memberikan implementasinya sendiri ke metode style() atau dengan kata lain meng-override metode style().
- Luas_lingkaran.java
  ini memakai sebuah overloading method.
- Super_keyword.java
  ini memakai sebuah override method.
