# 1.Jelaskan apa yang dimaksud dengan class dan object?
- Class
Class merupakan tempat untuk membuat obyek(blue print).
Di dalam class dideklarasikan variabel dan method yang dimiliki oleh obyek.
Proses pembuatan obyek dari sebuah class disebut dengan instantiation.
Jadi obyek merupakan hasil instansiasi dari class.
Obyek disebut juga dengan instance.
- Object
Object adalah Semua hal yang ada dalam dunia nyata, baik konkrit maupun abstrak
Contoh obyek konkrit : rumah, sekolah, dosen, mahasiswa, dan lain-lain.
Contoh obyek abstrak : mata kuliah, penjadwalan, dan lain-lain.

# 2.Sebutkan dan jelaskan jenis-jenis method?
Elemen penting yang termasuk dalam pembuatan class dan object adalah method.
Pada umumnya method dapat berupa fungsi ataupun prosedur yang digunakan
untuk melakukan input, output ataupun mengambil nilai dari variabel. Sedangkan jenis method terbagi
## 2 jenis yaitu Setter (Mutator) dan Getter (Accessor).
- Setter (Mutator)
Method setter (prosedur) digunakan untuk memberikan nilai ataupun untuk
menampilkan nilai dari variabel, sehingga tidak memerlukan return value.
- Getter (Accessor)
method getter (fungsi) digunakan untuk mengambil  nilai dari variabel, sehingga membutuhkan return value.