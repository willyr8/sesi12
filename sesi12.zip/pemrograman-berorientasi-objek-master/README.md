## Object Oriented Programming

OOP merupakan suatu metode pemrograman yang berorientasi kepada objek. Dalam bahasa Indonesia OOP dikenal dengan PBO (Pemrograman Berorientasi Objek).

---

### Requirement

- Pastikan sudah mendownload **``netbeans``** atau **``vscode``**
- Kemudian jangan lupa untuk menginstal juga **``JRE``**

---

## Author
- [Muhamad Iqbal Ramadhan](https://github.com/iqbalramdhan)