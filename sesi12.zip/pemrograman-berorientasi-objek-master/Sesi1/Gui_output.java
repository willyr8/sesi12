//Modified By Muhamad Iqbal Ramadhan
package Sesi1;
import javax.swing.*;

class Gui_output{
    public static void main(String[] args) {
        String input = JOptionPane.showInputDialog("Anda sedang belajar apa? ");
        JOptionPane.showMessageDialog(null,"Belajar " + input + " sangat mudah");
    }
}
