//Modified By Muhamad Iqbal Ramadhan
package Sesi1;

public class Cli_output{
    public static void main(String[] args) {
        System.out.println("Belajar JAVA");
        System.out.println("Sangat mudah sekali");
        System.out.println("dan sangat menyenangkan");
    }
}